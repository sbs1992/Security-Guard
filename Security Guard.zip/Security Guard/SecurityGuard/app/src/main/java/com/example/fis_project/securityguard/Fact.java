package com.example.fis_project.securityguard;

import java.util.ArrayList;

/*
* This class consist on an arraylist named fact_list which holds all the base facts and the new facts dynamically getting generated
* when a corresponding rule is fired
*
*
* */
public class Fact {

     String fact_name="";

    public static ArrayList<String> fact_list=new ArrayList<String>();


    public void Fact(String fact_name){

        this.fact_name=fact_name;

        addFact();

    }

    public void addFact(){

        if(!fact_list.contains(fact_name)){

            fact_list.add(fact_name);

        }

    }




}
