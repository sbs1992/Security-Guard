package com.example.fis_project.securityguard;

import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/*
* This class is the inference engine which consumes the rules and facts. produces new facts and finally provides the output in the form of total points and
* level of security.
* */


public class InferenceEngine {


    public String[] evaluation(){

        int out_off=(Fact.fact_list.size()-1)*2;

        String[] output=new String[2];
        HashMap<String,Boolean> recorded =new HashMap<String, Boolean>();
        List<String> useless = new ArrayList<>();

        int i =0;

        //parsing the rules
        for(String s : Rules.rules){
            // identifying the antecedent and consequent of the rules
            String mysplit[]=(s).split(">");
            String myAntecedent[]=mysplit[0].split("&&");

            if(! useless.contains(myAntecedent[0]) ) {

                if (Fact.fact_list.contains(myAntecedent[0]) &&  Fact.fact_list.get(Fact.fact_list.size()-1).equals(myAntecedent[1].trim())) {
                    useless.add(myAntecedent[0]);
                    Fact.fact_list.add(mysplit[1].trim());


                }

            }
            }


        for(String s1: Fact.fact_list){
             Log.e(" Fact_List, Now",s1+"");
        }









        Log.e("out",Fact.fact_list.size()+"");
        output[0]=Fact.fact_list.get(Fact.fact_list.size()-1)+"/"+out_off;

        int percent=(Integer.parseInt(Fact.fact_list.get(Fact.fact_list.size()-1).trim())*9)/out_off;


        useless.clear();
        for(String s : Rules.rules){
            String mysplit[]=(s).split(">");
            String myAntecedent[]=mysplit[0].split("\\|\\|");

            String uselessVal="";
            for(String gg:myAntecedent){
                uselessVal+=gg;
            }

            if(! useless.contains(uselessVal) && !uselessVal.contains("&&") ) {


                if (uselessVal.contains(percent+"")) {
                    useless.add(uselessVal);
                    Fact.fact_list.add(mysplit[1].trim());


                }

            }
        }







        output[1]=Fact.fact_list.get(Fact.fact_list.size()-1);

        return output;
    }
}
