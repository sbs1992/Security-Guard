/**
 * SecurityGuard
 *
 * @version  $Id: MainActivity.java, 1.0
 *
 * @author  Indrajeet Vidhate
 * @author  Soumyabhusan Sasmal
 * @author  Hanmant Lokare
 *
 */

package com.example.fis_project.securityguard;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static android.Manifest.permission.ACCESS_COARSE_LOCATION;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.Manifest.permission.ADD_VOICEMAIL;
import static android.Manifest.permission.ANSWER_PHONE_CALLS;
import static android.Manifest.permission.BODY_SENSORS;
import static android.Manifest.permission.CALL_PHONE;
import static android.Manifest.permission.GET_ACCOUNTS;
import static android.Manifest.permission.PROCESS_OUTGOING_CALLS;
import static android.Manifest.permission.READ_CALENDAR;
import static android.Manifest.permission.READ_CALL_LOG;
import static android.Manifest.permission.READ_CONTACTS;
import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.READ_PHONE_NUMBERS;
import static android.Manifest.permission.READ_PHONE_STATE;
import static android.Manifest.permission.READ_SMS;
import static android.Manifest.permission.RECEIVE_MMS;
import static android.Manifest.permission.RECEIVE_SMS;
import static android.Manifest.permission.RECEIVE_WAP_PUSH;
import static android.Manifest.permission.RECORD_AUDIO;
import static android.Manifest.permission.SEND_SMS;
import static android.Manifest.permission.USE_SIP;
import static android.Manifest.permission.WRITE_CALENDAR;
import static android.Manifest.permission.WRITE_CALL_LOG;
import static android.Manifest.permission.WRITE_CONTACTS;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import static android.Manifest.permission_group.CAMERA;

/**
 * MainActivity class
 *
 * This class is responsible for checking particular feature security level
 * and calling another activity
 *
 */
public class MainActivity extends AppCompatActivity {


    int x =0;
    int y=0;
    int z=0;
    int a=0;
    int b=0;
    int k=0;
    int l=0;
    TextView result;
    private String TAG ="";
    private List<String> list_of_permission;
    List<ScanResult> srl;
    WifiManager wm;
    int out1=0;
    String id;
    BroadcastReceiver rr;
    InferenceEngine engine;

    @Override
    protected void onDestroy(){
        super.onDestroy();
        unregisterReceiver(rr);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Context context =getApplicationContext();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        int BVS = Build.VERSION.SDK_INT;
        int BVC = Build.VERSION_CODES.M;
        if(BVS>=BVC) {

            if (checkSelfPermission(ACCESS_COARSE_LOCATION) !=PackageManager.PERMISSION_GRANTED) {

                requestPermissions(new String[]{ACCESS_COARSE_LOCATION}, 87);
            }
        }

        result = (TextView) findViewById(R.id.final_score);
        Button scan =(Button)findViewById(R.id.button);

        scan.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {


                CheckBox network = (CheckBox) findViewById(R.id.Network_type_check_checkbox);
                if (network.isChecked()) {
                    x = 1;
                }

                CheckBox screen = (CheckBox) findViewById(R.id.screen_lock_checkbox);
                if (screen.isChecked()) {
                    y = 1;
                }

                CheckBox software = (CheckBox) findViewById(R.id.software_checkbox);
                if (software.isChecked()) {
                    z = 1;
                }

                CheckBox all_app_check = (CheckBox) findViewById(R.id.all_app_checkbox);
                if (all_app_check.isChecked()) {
                    b = 1;
                }

                CheckBox developer_check = (CheckBox) findViewById(R.id.developer_checkbox);
                if (developer_check.isChecked()) {
                    k = 1;

                }

                CheckBox superuser = (CheckBox) findViewById(R.id.super_user_checkbox);
                if (superuser.isChecked()) {
                    l = 1;

                }

/**
 * This if condition checks if all app checkbox is checked or not.
 * In this we will check the permission taken by each application
 * and at we will decide overall security considering number of application
 * taking dangerous permissions
 */

if(x==1 || y==1 || z==1 || b==1 || k==1 || l==1) {
    if (b == 1) {
        int count = 0;
        int total_count = 0;
        list_of_permission = new ArrayList<String>();
        List<String> resul = new ArrayList<>();
        String[] dangerous_permissions = {READ_CALENDAR,
                WRITE_CALENDAR,
                CAMERA,
                READ_CONTACTS,
                WRITE_CONTACTS,
                GET_ACCOUNTS,
                ACCESS_FINE_LOCATION,
                ACCESS_COARSE_LOCATION,
                RECORD_AUDIO,
                READ_PHONE_STATE,
                READ_PHONE_NUMBERS,
                CALL_PHONE,
                ANSWER_PHONE_CALLS,
                READ_CALL_LOG,
                WRITE_CALL_LOG,
                ADD_VOICEMAIL,
                USE_SIP,
                PROCESS_OUTGOING_CALLS,
                BODY_SENSORS,
                SEND_SMS,
                RECEIVE_SMS,
                READ_SMS,
                RECEIVE_WAP_PUSH,
                RECEIVE_MMS,
                READ_EXTERNAL_STORAGE,
                WRITE_EXTERNAL_STORAGE};

        PackageManager pm = getPackageManager();
        List<PackageInfo> packages = pm.getInstalledPackages(PackageManager.GET_META_DATA);
        for (PackageInfo pi : packages) {

            try {
                PackageInfo packageInfo = pm.getPackageInfo(pi.packageName, pm.GET_PERMISSIONS);

                if (packageInfo.requestedPermissions != null) {
                    for (int i = 0; i < packageInfo.requestedPermissions.length; i++) {
                        if ((packageInfo.requestedPermissionsFlags[i] & PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0) {
                            String per = packageInfo.requestedPermissions[i];
                            per = per.substring(per.lastIndexOf(".") + 1);
                            list_of_permission.add(per);
                            total_count++;
                        }
                    }

                    for (String perm : dangerous_permissions) {
                        if (Collections.frequency(list_of_permission, perm) == 1) {
                            count++;
                        }
                    }

                    if (count == 0 || total_count == 0) {
                        resul.add("High");

                    } else {
                        int avg = (count / total_count) * 100;

                        if (avg < 70) {
                            resul.add("High");
                        } else {
                            resul.add("low");
                        }

                    }
                }
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }
            total_count = 0;
            count = 0;
        }


        int h = Collections.frequency(resul, "High");
        int l = Collections.frequency(resul, "low");
        Log.e("high", "" + h);
        Log.e("low", "" + l);

        String re = "";
        if (h > l) {
            Fact.fact_list.add("All Apps security is good ");

        } else {
            Fact.fact_list.add("All Apps security is risky ");

        }


    }

/**
 *
 * This if condition checks if all Software checkbox if checked or not.
 * In this we used Android API to check if the system is updated or not.
 */
    if (z == 1) {

        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.O_MR1) {

            Fact.fact_list.add("OS version is latest ");

        } else {

            Fact.fact_list.add("OS version is old ");
        }

    }

/**
 * This if condition checks if all super user checkbox is checked or not.
 * In this will check if the superuser.apk file is present in system,
 * If the file is present that means device is rooted and has root privileges.
 */
    if (l == 1) {

        String[] file_path_name = {"/system/app/Superuser.apk"};
        for (String s : file_path_name) {
            if (new File(s).exists())

                Fact.fact_list.add("Root privilages is enabled ");
            break;
        }

        Fact.fact_list.add("Root privilages is disabled ");

    }

/**
 * This if condition checks if all Screen lock checkbox is checked or not.
 * In this we will use KeyguardManager API to find the screenlock security level
 * of the device
 */
    if (y == 1) {

        try {

            int out = 0;
            int type;
            String sout = "";

            KeyguardManager km = (KeyguardManager) getSystemService(Activity.KEYGUARD_SERVICE);

            if (!km.isKeyguardSecure()) {

                Log.e("factlist at start: ", Fact.fact_list.size() + "");

                Fact.fact_list.add("ScreenLock is disabled ");

                Log.e("done", "done");
                Log.e("factlist: ", Fact.fact_list.size() + "");

                AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
                adb.setCancelable(true);
                adb.setTitle("No screen lock");
                adb.setMessage("Do you want to set a screen lock");
                adb.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                adb.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        startActivityForResult(new Intent(DevicePolicyManager.ACTION_SET_NEW_PASSWORD), 0);
                    }
                });

                AlertDialog ad = adb.create();
                ad.show();

            } else {


                Fact.fact_list.add("ScreenLock is enabled ");
                Log.e("factlist: is high ", Fact.fact_list.size() + "");
            }


            ;
        } catch (Exception e) {

            Log.e("error", e.getMessage() + "");

        }
    }

    // checking if the development options is on or not.
    if (k == 1) {

        String text = "";
        int value = Settings.Secure.getInt(getApplicationContext().getContentResolver(),
                Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0);

        boolean f = ((value > 0) ? true : false);
        if (f == true) {

            Fact.fact_list.add("Developer option is enabled ");
        } else {

            Fact.fact_list.add("Developer option is disabled ");
        }



    }


    /**
     * This if condition checks if network type check checkbox is checked or not.
     * In this we will use ConnectivityManager to get the connectivity_service
     * and match with type mobile.
     */
    if (x == 1) {

        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        if (cm.getActiveNetworkInfo() != null) {

            if (cm.getActiveNetworkInfo().getType() == ConnectivityManager.TYPE_MOBILE) {

                out1 = 30;
                Fact.fact_list.add("NetworkConnection is Private ");

                Log.e("In Mobile", out1 + "");


                Fact.fact_list.add("0");
                InferenceEngine IE = new InferenceEngine();
                String final_result = "";
                for (String answer : IE.evaluation()) {
                    final_result += answer + " ";
                }
                result.setText(final_result);
                Fact.fact_list.clear();


            } else if (cm.getActiveNetworkInfo().getType() == ConnectivityManager.TYPE_WIFI) {

                Log.e("In Wifi start", out1 + "");
                wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);

                id = wm.getConnectionInfo().getSSID();

                wm.startScan();

                registerReceiver(rr = new BroadcastReceiver() {
                    @Override
                    public void onReceive(Context context, Intent intent) {
                        srl = wm.getScanResults();

                        out1 = 10;

                        String[] seccodes = {"WPA", "WPA2", "WEP", "WPS", "WPA_EAP", "IEEE8021X"};
                        for (int i = 0; i < srl.size(); i++) {


                            if (id.substring(1, id.length() - 1).equals(srl.get(i).SSID)) {

                                for (int j = 0; j < seccodes.length; j++) {


                                    if (srl.get(i).capabilities.contains(seccodes[j])) {
                                        out1 = 20;


                                        break;
                                    }
                                }
                                break;
                            }

                        }

                        Log.e("In wifi end", out1 + "");
                        if (out1 == 10) {
                            Fact.fact_list.add("NetworkConnection is Open type ");
                        } else {
                            Fact.fact_list.add("NetworkConnection is Private ");
                            Log.e("In Mobile Else C", "");
                        }


                        Fact.fact_list.add("0");
                        InferenceEngine IE = new InferenceEngine();
                        String final_result = "";
                        for (String answer : IE.evaluation()) {
                            final_result += answer + " ";
                        }
                        result.setText(final_result);
                        Fact.fact_list.clear();
                        unregisterReceiver(rr);
                    }
                }, new IntentFilter(wm.SCAN_RESULTS_AVAILABLE_ACTION));


            }

        } else {

            Toast.makeText(MainActivity.this, "Internet connectivity not present", Toast.LENGTH_LONG).show();

        }

    }

//we unchecked all the checkbox after all activity take place.
    network.setChecked(false);
    screen.setChecked(false);
    software.setChecked(false);
    all_app_check.setChecked(false);
    developer_check.setChecked(false);
    superuser.setChecked(false);



    // Evaluation
    if (x != 1) {
        Fact.fact_list.add("0");
        InferenceEngine IE = new InferenceEngine();
        String final_result = "";
        for (String answer : IE.evaluation()) {
            final_result += answer + " ";
        }
        result.setText(final_result);
        Fact.fact_list.clear();
    }
    x = 0;
    y = 0;
    z = 0;
    b = 0;
    k = 0;
    l = 0;


}
else{

    Toast.makeText(MainActivity.this, "please select an option before starting the scan", Toast.LENGTH_LONG).show();
}



            }

        });
    }


    public String evaluator(int val,String s){
        String op="";
        if(val==30){
            op="Security is High";
        }
        else if(val==20){
            op="Security is Moderate";
        }
        else if(val==10){
            op="Security is Low";
        }


        return op;
    }

    /**
     * This mwthod will start Main2Activity
     *
     * @param view
     */
    public void app_check(View view) {
        Button btn = (Button)findViewById(R.id.app_check_button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Main2Activity.class));

            }
        });

    }
}
