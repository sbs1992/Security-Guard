/**
 * SecurityGuard
 *
 * @version  $Id: Main2Activity.java, 1.0
 *
 * @author  Indrajeet Vidhate
 * @author  Soumyabhusan Sasmal
 * @author  Hanmant Lokare
 *
 */


package com.example.fis_project.securityguard;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import static android.R.layout.simple_list_item_1;

/**
 * This class is responsible to display all the application package name
 * and to display all the permission check taken by an application.
 */
public class Main2Activity extends AppCompatActivity  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        ArrayList<String> list_of_pacakge_name =new ArrayList<String>();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        final PackageManager pm = getPackageManager();

        List<PackageInfo> packages = pm.getInstalledPackages(PackageManager.GET_META_DATA);

        for (PackageInfo pi : packages) {

            list_of_pacakge_name.add(pi.packageName);
            try {
                PackageInfo packageInfo = pm.getPackageInfo(pi.packageName, pm.GET_PERMISSIONS);

                if(packageInfo.requestedPermissions!= null){
                    for (int i = 0; i < packageInfo.requestedPermissions.length; i++) {
                        if ((packageInfo.requestedPermissionsFlags[i] & PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0) {
                            String per = packageInfo.requestedPermissions[i];
                            per = per.substring(per.lastIndexOf(".") + 1);

                        }
                    }}
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }

        }



        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(Main2Activity.this, android.R.layout.simple_list_item_1, list_of_pacakge_name);
        final ListView listView = (ListView) findViewById(R.id.list_of_package_name);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {


                try
                {
                    List<String> arr = new ArrayList<String>();
                    PackageInfo pac = getPackageManager().getPackageInfo(String.valueOf(parent.getItemAtPosition(position)),PackageManager.GET_PERMISSIONS);

                    if(pac.requestedPermissions!= null)
                    {

                        for (int i = 0; i < pac.requestedPermissions.length; i++)
                        {
                            if ((pac.requestedPermissionsFlags[i] & PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0)
                            {
                                String per = pac.requestedPermissions[i];
                                per = per.substring(per.lastIndexOf(".") + 1);

                                arr.add(per);
                            }
                        }

                    }
                    StringBuilder sb = new StringBuilder();
                    sb.append("These are the list of permission taken");
                    sb.append("\n");
                    for (String s : arr)
                    {
                        sb.append(s);
                        sb.append("\t");
                    }
                    Toast.makeText(Main2Activity.this, sb.toString(), Toast.LENGTH_LONG).show();

                }
                catch (PackageManager.NameNotFoundException e)
                {
                    e.printStackTrace();
                }


            }
        });
    }
}
